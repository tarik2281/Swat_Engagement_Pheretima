<?xml version="1.0" encoding="UTF-8"?>
<tileset name="OverWorldTiles" tilewidth="16" tileheight="16" tilecount="638" columns="29">
 <image source="OverWorldTiles.png" width="464" height="352"/>
</tileset>
