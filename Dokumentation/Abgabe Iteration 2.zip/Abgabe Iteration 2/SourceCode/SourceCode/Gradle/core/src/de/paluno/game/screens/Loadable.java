package de.paluno.game.screens;

import com.badlogic.gdx.assets.AssetManager;

public interface Loadable {
    boolean load(AssetManager manager);
}
