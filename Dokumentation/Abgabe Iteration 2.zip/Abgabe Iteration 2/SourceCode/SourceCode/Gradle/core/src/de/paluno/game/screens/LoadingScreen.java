package de.paluno.game.screens;

public class LoadingScreen {
}
