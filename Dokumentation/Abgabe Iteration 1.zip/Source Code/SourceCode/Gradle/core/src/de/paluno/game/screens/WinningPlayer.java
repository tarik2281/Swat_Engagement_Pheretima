package de.paluno.game.screens;

public enum WinningPlayer {

	PLAYERONE,
	PLAYERTWO;
	
	
	private  WinningPlayer(){
		
	}
	
}
// EJDBEJFH