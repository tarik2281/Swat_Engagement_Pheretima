package de.paluno.game;

public enum GameState {
	PLAYERONETURN,
	PLAYERTWOTURN,
	SHOOTING,
	GAMEOVERPLAYERONEWON,
	GAMEOVERPLAYERTWOWON;
	
	
	 
	
	
	
	
}
