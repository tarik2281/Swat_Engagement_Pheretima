package de.paluno.game.interfaces;

public class EndTurnEvent extends GameEvent {
}
