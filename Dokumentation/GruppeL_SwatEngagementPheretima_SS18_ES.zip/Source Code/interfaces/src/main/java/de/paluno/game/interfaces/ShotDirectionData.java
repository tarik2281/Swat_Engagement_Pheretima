package de.paluno.game.interfaces;

public class ShotDirectionData {
    public float angle;
}
