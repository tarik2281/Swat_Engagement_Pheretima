package de.paluno.game.interfaces;

public class PlayerMessage extends Message {


}
