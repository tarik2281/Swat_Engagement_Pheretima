package de.paluno.game.interfaces;

public class LobbyListRequest {

    public static class Result {

        public LobbyData[] lobbies;
    }


}
