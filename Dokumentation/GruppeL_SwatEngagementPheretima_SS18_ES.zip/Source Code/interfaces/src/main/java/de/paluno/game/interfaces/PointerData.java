package de.paluno.game.interfaces;

public class PointerData {
    public float x;
    public float y;
}
