package de.paluno.game.interfaces;

public class ShootingData extends GameData {



    public ShootingData() {

    }


}
