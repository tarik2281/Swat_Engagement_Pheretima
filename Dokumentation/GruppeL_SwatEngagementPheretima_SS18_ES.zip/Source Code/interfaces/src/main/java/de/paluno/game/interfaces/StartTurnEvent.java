package de.paluno.game.interfaces;

public class StartTurnEvent {

    public int playerNumber;
    public int wormNumber;
    public int wind;
}
