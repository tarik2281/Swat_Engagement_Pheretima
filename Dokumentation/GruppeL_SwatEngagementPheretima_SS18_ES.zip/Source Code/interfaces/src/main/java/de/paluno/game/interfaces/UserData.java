package de.paluno.game.interfaces;

public class UserData {

    public int id;
    public String name;
}
