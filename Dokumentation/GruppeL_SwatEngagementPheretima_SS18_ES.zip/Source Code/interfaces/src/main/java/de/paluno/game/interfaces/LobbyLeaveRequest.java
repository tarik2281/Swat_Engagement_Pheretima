package de.paluno.game.interfaces;

public class LobbyLeaveRequest {

    public static class Result {
        public boolean success;
    }
}
