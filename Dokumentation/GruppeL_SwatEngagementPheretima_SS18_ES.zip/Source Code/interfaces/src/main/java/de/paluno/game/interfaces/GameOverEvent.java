package de.paluno.game.interfaces;

public class GameOverEvent {
    public int winningPlayer;
}
