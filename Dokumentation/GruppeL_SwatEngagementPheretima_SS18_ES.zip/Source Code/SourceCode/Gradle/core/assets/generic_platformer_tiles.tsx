<?xml version="1.0" encoding="UTF-8"?>
<tileset name="generic_platformer_tiles" tilewidth="16" tileheight="16" tilecount="3072" columns="64">
 <image source="generic_platformer_tiles.png" width="1024" height="768"/>
</tileset>
