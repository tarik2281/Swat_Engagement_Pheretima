package de.paluno.game;

public enum GameState {
	NONE,
	PLAYERTURN,
	SHOOTING,
	WAITING,
	DROPPING,
	RAISE_WATER_LEVEL,
	IDLE
}
