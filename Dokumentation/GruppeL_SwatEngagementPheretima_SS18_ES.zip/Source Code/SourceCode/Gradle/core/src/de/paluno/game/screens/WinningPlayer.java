package de.paluno.game.screens;

public enum WinningPlayer {

	NONE,
	PLAYERONE,
	PLAYERTWO;
	
	
	private  WinningPlayer(){
		
	}
	
}
// EJDBEJFH